
// 주석
// 프로그램의 시작부분

// a != A

fn main(){
    println!("aaabbbccc"); // 출력 테스트
    println!("aaabbbccc"); /* 출력 테스트 */
    println!("aaabbbccc");

    println!("{}", 1 + 2 * 3  + 4);
    // sub01();
}

// fn sub01(){}

// // 정수 출력
// fn main() {
//     println!("3-숫자 : 85");
//     println!("4-숫자 : {}", "85");
//     println!("5-숫자 : {}", 85);
//     println!("6-숫자 : {}", 000085);
//     println!("7-숫자 : {}", 1_700_000);
// }


// 여러줄 출력
// fn main() {
//     print!("첫번째줄\naaaa\nbbb");
// }

// 리터럴 문자열 조합
// fn main() {
//     println!("{}", "hello");
//     // "{} {}" : 포맷 문자열
//     //      {} : 위치 지정자.
//     // "hello" : 1 데이터
//     // "world" : 2번째 데이터
// }
