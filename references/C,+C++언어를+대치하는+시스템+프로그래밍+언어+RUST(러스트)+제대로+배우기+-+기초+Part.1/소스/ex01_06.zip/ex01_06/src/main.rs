// 타입 가변성
fn main(){
    let mut n = 1;
    println!("{}", n);

    n = 2;
    println!("{}", n);

    n = 3;
    println!("{}", n);

    let mut n = 3.14;
    println!("13:{}", n);
    n = 5.1;
    println!("15:{}", n);
}

// // 타입 추론
// fn main(){
//     let a;
//     a = 12;
//
//     let b = a;
//     let c = b;
// }

// // 대입 연산자의 타입 일관성
// fn main(){
//     let mut n= 1.0;
//     // println!("{}", n);
//     n = 2.;
//     println!("{}", n);
//     n = 3.;
//     println!("{}", n);
//     n = 3.14;
//     println!("{}", n);
// }


// // 부울 표현식
// // and, or, not
// // and : && 2
// // or : || 3
// // not : ! 1
// fn main(){
//     let 참 = true;
//     let 거짓 = false;
//
//     println!("{} {} {} {}", 거짓 && 거짓, 거짓 && 참, 참 && 거짓, 참 && 참);
//     println!("{} {} {} {}", 거짓 || 거짓, 거짓 || 참, 참 || 거짓, 참 || 참);
//     println!("{}", !참);
//
//     println!("{}", (참 || 참) && !참);   //   참 && 거짓  => 참 || 거짓 => 참
// }

// // 부울 값
// // 참, 거짓 : true, false
// // 부울변수
// // 부울 연산자
// //   == : 같다
// //   != : 같지 않다
// //   >, >= , < , <=
// //   !   : Not
// fn main() {
//     let 참 = 5 > 1;
//     let 거짓 = -9.4 >= -3.1;
//
//     println!("{} {}", 참, 거짓);
//
//     println!("{}", 10 >= 5);
//
//     // 코드값..
//     println!("{}", "abcb" > "abda");
//     println!("{}", "A" > "a");  // 4바이트
// }
