// _
// 미사용 변수의 경고 메시지 생략
fn main(){
    let _n = 10;    // _n  != n
    let n = 20;
    let _ = 30;

    println!("{}", n);
    // println!("{}", _n);
    // println!("{}", _);
}

// // 3. 지연된 초기화
// fn main(){
//     let n1;
//     n1 = 10;
//     println!("{}", n1);
// }


// // 2. 가변 변수
// // 변수에 값을 바꾸고자 하면,
// // let mut 변수명;  mutable   <-> immutable(default)
// // c : int const n = 12;    => let n = 12;
//
// fn main(){
//     let mut n = 12;
//     println!("n={}", n);
//     n = 65;
//     println!("n={}", n);
// }


// // 변수
// // let 변수명;
//
// // let n = 12;  => rust 반드시 변수 타입을 선언..
// // let 변수명 : 타입;
// // let 변수명 : 타입 = 초기값;
// // 모든 변수는 선언후 사용!!
// // 변수값은 변경 불가능!!
// fn main() {
//     let n = 12;  //  스택에 1. 정수를 저장할 영역확보, 2. 영역을 n에 배당, 3. 해당 영역에 12 대입
//     let n2 = 51; //
//
//     println!("{}", n + n2);
//
//     // println!("y={}", y);
//     // n = 20;
//     println!("{}", n);
// }
//
