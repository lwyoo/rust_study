// [2] 표현식
fn main() {
    let a = 4;
    // a 가 10 보다 크거나 같으면, 3의로 나눈 나머지,
    // 10보다 작으면 2로 나눈 나머지를

    // let n ;
    //
    // if a >= 10 {
    //     n = a % 3;
    // } else {
    //     n = a % 2;
    // }
    //  표현식
    // let n = if a >= 10 { a % 3 } else { a % 2 } ;
    // 3항 연사자
    // let n = a>=10 ? a%3 : a%2 ;

    let n = if a < 10 { a % 2 } else {a % 3};

    println!("{}의 나머지는 {}", a, n);
}

// // [1] if 문
// // if 조건식 {
// //      참일경우 처리문..
// // } else {
// //      거짓 일경우 처리문..
// // }
//
// fn main() {
//     let 예선합격 = false;
//     let n = 5;
//
//     if 예선합격 {
//         if n >= 6 {
//             println!("합격.");
//         } else if n <= 3 {
//             println!("탈락.");
//         } else {
//             println!("보류");
//         }
//     } else {
//         println!("탈락, 다음 예선에 참가 하세요~!");
//     }
// }
