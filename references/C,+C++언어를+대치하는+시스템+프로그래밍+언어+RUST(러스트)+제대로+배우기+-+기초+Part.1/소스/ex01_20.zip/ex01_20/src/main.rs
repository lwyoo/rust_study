// 구조체(Structs)
/*
    struct 스트럭쳐명{
        필드명1:타입1,
        필드명2:타입2,
        :
    }

    let data = 스트럭쳐명{
        필드명1 : 데이터1,
        필드명2 : 데이터2
    };

    data.필드명1 // 사용법
 */

fn main() {
    // 튜플은 필드의 갯수가 적을 경우 주로 사용
    let data = (10, 27, 'A', 15, 10, 3.14, 'W', false, -22);
    println!("{}", data.3 + data.8);
    // let data2:(i32, char, i32, f64, char, bool, i32) = data;
    // println!("{:?}", data2);

    struct 고객 {
        나이: i32,
        아이큐 : i32,
        몸무게: f64,
        등급: char,
        비밀번호: [u8; 5],
    }
    ;

    let 홍길동 = 고객 {
        나이: 21,
        몸무게: 67.3,
        등급: 'B',
        비밀번호: [6, 2, 1, 7, 4],
    };


    println!("홍길동 나이:{}, 몸무게:{}, 등급:{}, 비밀번호 끝 두자리:{}{}",
            홍길동.나이, 홍길동.몸무게, 홍길동.등급, 홍길동.비밀번호[3], 홍길동.비밀번호[4]);

    // 빈 구조체, 빈 튜플
    struct NoData{};
    let a = NoData{};
    let b = ();
}

// 튜플(Tuple)
// (테이터1, 테이터2.....) 단, 타입이 서로 달라도 된다.
// fn main(){
//     let mut data = (1000, 3.14, 'A');
//     let data2:(i32, f32, char) = data;
//
//
//     println!("{}, {}, {}",data2.0, data2.1, data2.2);
//     println!("{:?}",data2);
//     data.0 = 5;
//     data.2 = 'W';
//     println!("{:?}",data);
//
//     // 인덱스 접근에 변수를 사용할수 없다.
//     let array = [11,22,33];
//     let tuple = (11,22,33);
//     println!("{}  {}", array[0], tuple.0);
//
//     let i = 0;
//     // 인덱스 접근에 변수를 사용할수 없다.
//     // println!("{}, {}", array[i], tuple.i); // 불가..
// }