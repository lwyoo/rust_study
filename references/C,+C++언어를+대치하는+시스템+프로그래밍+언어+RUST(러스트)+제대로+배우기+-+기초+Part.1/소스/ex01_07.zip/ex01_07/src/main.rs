// 표준 라이브러리 함수
fn main(){
    let mut l = 0;  // 부호가 없는, 음수가 없고, 모두 양수.
    //           abcdefg
    //           가나다라
    let s = "가나다라";
    let s1 = "📱😂";
    l = s.len();
    println!("{}의 len : {}", s, l);

    l = s1.len();
    println!("{}의 len : {}", s1, l);

    // 변수, 상수 .
    // "abcd".len();  객체지향 문법.
    // 절차 지향 => 함수 호출 호출
    //      자료형::함수()
    l = str::len(s);    // str module
    
}


// // 복합 할당 연산자
// fn main(){
//     let mut x = 1;
//     println!("{}",x);
//
//     x = x + 1;
//     println!("{}",x);
//
//     x += 2;
//     println!("{}",x);
//
//     // +=, -=, *= , /=
//
//     let mut a = 12;
//     a += 1; // a = a + 1;
//     a -= 5; // a = a - 5;
//     a *= 2; // a = a * 2;
//     a /= 8; // a = a / 8;
//     println!("{}",a);
// }

// fn main() {
//     let x = 120;
//     println!("{}", x);
//
//     let x = "abcd";
//     println!("{}", x);
//
//     let mut x = true;
//     println!("{}", x);
//     x = false;
//     println!("{}", x);
// }
