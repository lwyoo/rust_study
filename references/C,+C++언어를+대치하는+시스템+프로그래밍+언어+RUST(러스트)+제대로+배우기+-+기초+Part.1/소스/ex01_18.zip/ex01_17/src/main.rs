// match 가드(if, while)
fn main() {
    // -5~5 0=> zero, 1 'one' , +=>양수,- =>음수

    for n in -5..6 {
        println!("{} {}", n, match n {
            0 => "zero",
            1 => "one",
            _ if n < 0 => "음수",
            _ => "양수"
        });
    }
}

// // match 표현식
// fn main(){
//     enum 방위{동,서, 남, 북}
//
//     let 진행방향 = 방위::북;
//
//     // 다른 문장속에 표현식으로 match 사용
//     println!("{}", match 진행방향 {
//         방위::북=>'N',
//         방위::남=>'S',
//         _=>'*'
//     });
//     // 표현식 => if, while, match
// }

// enum 을 사용한 자료형 지정
// fn main(){
//     enum Result {
//         Success(u8),
//         Failure(u16, char),
//         Uncertaity,
//     }
//
//     let ret = Result::Failure(20, 'X');
//
//     match ret{
//         Result::Success(0)=>println!("Success:0"),
//         Result::Success(1)=>println!("Success:1"),
//         Result::Success(_)=>println!("Success:other"),
//         Result::Failure(10,'E')=>println!("Erroe:10 - E"),
//         Result::Failure(10,_)=>println!("Erroe:10 - other"),
//         Result::Failure(_,'L')=>println!("Erroe:other - LoginError"),
//         Result::Failure(_,_)=>println!("Erroe:other - etc..."),
//         Result::Uncertaity => {}
//     }
//
//     let ret2 = Result::Failure(20, 'T');
//     let a = 99;
//     match ret2{
//         Result::Success(0)=>println!("Success:0"),
//         Result::Success(1)=>println!("Success:1"),
//         Result::Success(a)=>println!("Success:{}",a),
//         Result::Failure(10,'E')=>println!("Erroe:10 - E"),
//         Result::Failure(10,c)=>println!("Erroe:10 - {}", c),
//         Result::Failure(_,'L')=>println!("Erroe:other - LoginError"),
//         Result::Failure(code, retChar)=>println!("Erroe:{} - {}..", code, retChar),
//         Result::Uncertaity => {}
//     }
//     println!("34:{}", a);
//
// }

// // 숫자, 문자, 문자열을 통한 match 구문
// fn main(){
//     // enum => match
//     // match => enum (x)
//     let a = "value";
//     match a {
//         "const" => println!("상수"),
//         "value" => println!("값"),
//         _ => println!("기타")
//     }
//
//     let b = 3;
//     match b {
//         1 => println!("하나"),
//         2 => println!("둘"),
//         3 => println!("셋"),
//         4 => println!("넷"),
//         _ => println!("기타")
//     }
//
//     let c = '.';
//     match c {
//         'a' => println!("고객등록"),
//         '.' => println!("종료"),
//         _ => println!("기타")
//     }
// }

// // 관계연산자와 enum
// fn main(){
//     enum 방위{동,서,남,북}
//
//     let 방향 = 방위::서;
//
//     // enum 은 if 문으로 비교 불가.
//     // if 방향 == 방위::동{
//     //     println!("귀인을 만난다");
//     // } else {
//     //     println!("꽝!");
//     // }
//     // if 방향 > 방위::동 {
//     //
//     // }
//
//     match 방향 {
//
//         방위::동 => println!("귀인을 만난다."),
//         방위::서 => println!("재물운이 있다."),
//         // 방위::남 => {},
//         // 방위::북 => {},
//         _ => {} // 모든 경우의 처리,
//     }
//
// }
// match 문의 구조
// fn main(){
//     //표현 식, 문장
//     // 표현식 => 표현식; => 문장
//     let a = 7.2;    // 실행문장
//     12;//  => 표현식
//     true;
//     4>7;
//     5.7 + 5.0 * a;
//
//     // match 변수 {
//     //     경우의수1 => 표현식1,
//     //     경우의수2 => 표현식2,
//     //     경우의수3 => {
//     //              aaaa;
//     //              bbbb;
//     //              cccc;
//     //      },
//     //     :
//     // }
// }


// enum
// fn main() {
//     const 유럽 : u8 = 0;
//     const 아시아 : u8 = 1;
//     const 아프리카 : u8 = 2;
//     const 아메리카 : u8 = 3;
//     const 오세아니아 : u8 = 4;
//
//     let 고객위치 = 아시아;
//
//     if 고객위치 == 유럽 {println!("E")}
//     else if 고객위치 == 아시아 {println!("As")}
//     else if 고객위치 == 아프리카 {println!("Af")}
//     else if 고객위치 == 아메리카 {println!("Am")}
//     else if 고객위치 == 오세아니아 {println!("O")}
// }
//
// fn main(){
//     #[allow(dead_code)]
//     enum 대륙{
//         유럽, // 0u8
//         아시아, // 1u8
//         아프리카, // 2u8
//         아메리카, // 3u8
//         오세아니아 // 4u8   256개  0000 0000 ~ 1111 1111
//     }
//
//     let 고객위치 = 대륙::아시아; // enum명::항목
//
//     match 고객위치 {
//         대륙::유럽 => println!("E"),
//         대륙::아시아 => println!("As"),
//         대륙::아프리카 => println!("Af"),
//         대륙::아메리카 => println!("Am"),
//         대륙::오세아니아 => println!("O"),
//     }
//
//     enum T {A, B, C, D} // u8
//     let n:T = T::D;
//     // let n2 : T = T::B;
// }