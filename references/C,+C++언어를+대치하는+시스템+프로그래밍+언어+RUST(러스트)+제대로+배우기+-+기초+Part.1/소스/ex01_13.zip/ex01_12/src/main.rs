// [12] 배열과 벡터의 복사
fn main(){
    let mut a1 = [10,20,30];
    let a2 = [40,50,60];
    println!("{:?} {:?}", a1, a2);

    a1 = a2;    // 값 복사
    println!("{:?} {:?}", a1, a2);

    a1[0] = 100;
    println!("{:?} {:?}", a1, a2);


    let mut v1 = vec![10, 20, 30];
    let v2 = vec![40, 50, 60];
    println!("16:{:?} {:?}", v1, v2);

    //
    // v1          v2
    // 100 50 60    40 50 60
    v1 = v2.clone();
    println!("18:{:?}", v1);
    v1[0] = 100;
    println!("20:v1=>{:?}", v1);
    println!("22:v2=>{:?}", v2);
}


// [11] 배열과 벡터의 출력
// => 디버그 프린트  "{:?}"
// fn main(){
//     let a = [10,20,30];
//     let v = vec![10,20,30];
//
//     println!("{:?}", a);
//     println!("{:?}", v);
// }

// [10] 빈 배열과 빈 벡터
// fn main(){
//     let a = [0;0];
//     let v = vec![0.0;0];
//     let s = ["";0];
// }


// [9] 벡터에서 사용할수 있는 추가 함수들
// fn main(){
//     let mut v1 = vec![10, 20, 30, 40];
//
//     for i in 0..v1.len(){print!("{} ", v1[i]);}println!("");
//
//     v1.insert(1, 500);  // 1번 방에 새로운 데이터 500을 넣어라.
//     for i in 0..v1.len(){print!("{} ", v1[i]);}println!("");
//
//     v1.remove(3);   // 3번방을 지워라.
//     for i in 0..v1.len(){print!("{} ", v1[i]);}println!("");
//
//     v1.push(600); // 제일 뒤에 삽입
//     for i in 0..v1.len(){print!("{} ", v1[i]);}println!("");
//
//     v1.pop();   // 제일 마지막 값 인출
//     for i in 0..v1.len(){print!("{} ", v1[i]);}println!("");
//
//     v1.insert(4, 999);  // v1.insert(v1.len(), 데이터) => v1.push(데이터);
//     for i in 0..v1.len(){print!("{} ", v1[i]);}println!("");
//
// }

// 벡터 장점
//  -.길이가 가변
//  -. 초기화시 갯수를 변수로 지정 가능
// fn main(){
//     let a = 10;
//     let x = 99;
//     let b = vec![x;a];
//
//     for i in 0..b.len(){
//         println!("8:{} => {}",i, b[i]);;
//     }
//
//     let mut c = vec![10, 20, 30];
//     c.push(30);
//     c = vec![100,200];
//
// }

// [8] 벡터
//   길이가 가변
// 단, 데이터 형은 고정.
// fn main() {
//     let mut menu = vec!["짜장", "짬뽕"];
//     println!("6:{}, {}, {}", menu[0], menu[1], menu.len());
//
//     menu.push("탕수육");
//     println!("9:{}", menu.len());
//     println!("10:{}", menu[menu.len()-1]);
//
//     menu.push("울면");
//     println!("13:{}", menu.len());
//
//     menu[0] = "간짜장";
//
//     // [0 ~ n-1]
//     for i in 0..menu.len(){
//         println!("19: {}=>{}", i, menu[i]);
//     }
// }
