struct 도서{
    제목:String,
    저자:String,
    위치:Option<String>
}

impl 도서{
    fn 새로운(제목:String, 저자:String)->도서{
        도서{
            제목, 저자, 위치 : None
        }
    }

    fn 위치_설정(&mut self, 위치:String){
        self.위치 = Some(위치);
    }

    fn 위치_확인(&self)->Result<&String, String>{
        match &self.위치{
            Some(위치)=> Ok(위치),
            None=>Err("도서 우치가 설정되어 있지 않습니다.".to_string()),
        }
    }
}

fn main(){
    let mut 책 = 도서::새로운("Rust프로그래밍".to_string(), "홍길동".to_string());
    책.위치_설정("거실 책장 2단".to_string());

    match 책.위치_확인() {
        Ok(위치)=>println!("도서위치:{}", 위치),
        Err(e)=>println!("오류:{}", e)
    }

}

// 어휘 규직
// fn main(){
//     // 상수 대문자로만 사용
//     const MAX:u8 = 100;
//     const MIN:u8 = 10;
//
//     // 타입들, 은 Pascal Case
//     // 첫문자는 대문자, 단어가 바뀌면 대문자
//     struct CustMaster{};
//     struct CustDetail{};
//     enum EmpGrad{}
//
//     // 첫문자가 소문자. x
//     // let custName = "홍길동";
//
//     // snake case
//     // 다 소문자로 단어와 단어 사이는 _ 연결
//     let cust_mas;
//     let cust_detail ;
// }

// 튜플 구조체
// 구조체 => 튜플같이 사용
//  => 고조체 장점 : 타입정의
//  => 튜플의 장점 : 플드명 없이 사용 가능
// 선언 + 필드명 생략 가능
// fn main(){
//     struct 튜구(
//         i32,
//         f32,
//         char,
//         [u8;5]
//     );
//     let data = 튜구(10_000_000, 3.14, 'A', [10,20,30,40,50]);
//     println!("{},{},{}", data.0, data.1, data.3[4]);
//     let data2 = 튜구(700, 1.2, 'B', [1,2,3,4,5]);
// }

// 구조체(Structs)
/*
    struct 스트럭쳐명{
        필드명1:타입1,
        필드명2:타입2,
        :
    }

    let data = 스트럭쳐명{
        필드명1 : 데이터1,
        필드명2 : 데이터2
    };

    data.필드명1 // 사용법
 */

// fn main() {
//     // 튜플은 필드의 갯수가 적을 경우 주로 사용
//     let data = (10, 27, 'A', 15, 10, 3.14, 'W', false, -22);
//     println!("{}", data.3 + data.8);
//     // let data2:(i32, char, i32, f64, char, bool, i32) = data;
//     // println!("{:?}", data2);
//
//     struct 고객 {
//         나이: i32,
//         아이큐 : i32,
//         몸무게: f64,
//         등급: char,
//         비밀번호: [u8; 5],
//     }
//     ;
//
//     let 홍길동 = 고객 {
//         나이: 21,
//         몸무게: 67.3,
//         등급: 'B',
//         비밀번호: [6, 2, 1, 7, 4],
//     };
//
//
//     println!("홍길동 나이:{}, 몸무게:{}, 등급:{}, 비밀번호 끝 두자리:{}{}",
//             홍길동.나이, 홍길동.몸무게, 홍길동.등급, 홍길동.비밀번호[3], 홍길동.비밀번호[4]);
//
//     // 빈 구조체, 빈 튜플
//     struct NoData{};
//     let a = NoData{};
//     let b = ();
// }

// 튜플(Tuple)
// (테이터1, 테이터2.....) 단, 타입이 서로 달라도 된다.
// fn main(){
//     let mut data = (1000, 3.14, 'A');
//     let data2:(i32, f32, char) = data;
//
//
//     println!("{}, {}, {}",data2.0, data2.1, data2.2);
//     println!("{:?}",data2);
//     data.0 = 5;
//     data.2 = 'W';
//     println!("{:?}",data);
//
//     // 인덱스 접근에 변수를 사용할수 없다.
//     let array = [11,22,33];
//     let tuple = (11,22,33);
//     println!("{}  {}", array[0], tuple.0);
//
//     let i = 0;
//     // 인덱스 접근에 변수를 사용할수 없다.
//     // println!("{}, {}", array[i], tuple.i); // 불가..
// }